// Paste your Supabase values here (Project Settings -> API). The anon key is meant to be public.
window.CFG={URL:'PASTE_PROJECT_URL_HERE',KEY:'PASTE_ANON_PUBLIC_KEY_HERE'};
